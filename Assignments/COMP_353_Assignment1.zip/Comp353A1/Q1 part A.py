import re

class Database:


    def __init__(self, attributes, name):
        self.entries = []
        self.attributes=attributes
        self.name = name
    

    def add(self, entry):
        self.entries.append(entry)
    def remove(self, predicate):
        for attribute in self.attributes:
            predicate.replace(attribute, "x.get("+attribute+")")
        for x in self.entries:
            if eval(predicate)==True:
                self.entries.remove(x)
    


class DBMS:
    def __init__(self):
        self.databases = {}

    def recursiveSelect(self, databases, attributes, condition):
        s=""
        if len(databases)>1:
            db = databases[0]
            for e in db.entries:
                c=condition.split()
                for x in c:
                    try:
                        if x.index("."):
                            if x[0:x.index(".")]==db.name:
                                if str(e.get(x[x.index(".")+1:])).isdigit():
                                    c[c.index(x)]=str(e.get(x[x.index(".")+1:]))
                                else:
                                    c[c.index(x)]="\""+e.get(x[x.index(".")+1:])+"\""
                    except ValueError:
                        pass
                c=" ".join(c)
                if self.recursiveSelect(databases[1:], attributes, c)!="":
                    s+=self.recursiveSelect(databases[1:], attributes, c)
                    for a in attributes:
                        try:
                            if a[0:a.index(".")]==db.name:
                                s+=a[a.index(".")+1:]+": "+str(e[a[a.index(".")+1:]])+" "
                        except KeyError:
                            pass
                
                
                    
        else:
            db = databases[0]
            for e in db.entries:
                c=condition.split()
                for x in c:
                    try:
                        if x.index("."):
                            if x[0:x.index(".")]==db.name:
                                if str(e.get(x[x.index(".")+1:])).isdigit():
                                    c[c.index(x)]=str(e.get(x[x.index(".")+1:]))
                                else:
                                    c[c.index(x)]="\""+e.get(x[x.index(".")+1:])+"\""
                    except ValueError:
                        pass
                c=" ".join(c)
                if eval(c):
                    s+="Result : "
                    for a in attributes:
                        try:
                            s+=a+": "+str(e[a])+" "
                        except KeyError:
                            pass
                    
                
                
        return s
                
        
    
    def queryHandler(self, query):
        query.strip()
        subquery=query.lower().split(" ")
        
        
        
        if subquery[0]=="create" and subquery[1]=="table":
            if len(subquery)>=3:
                self.databases[subquery[2]]=Database(subquery[3:], subquery[2])
                return
        if subquery[0]=="insert" and subquery[1]=="into":
            dictName=subquery[2]
            entryItems=subquery[3:]
            newSet={}
            
            for item in entryItems:
                i =item.split("=")
                newSet[i[0]]=i[1]
                if i[1].isdigit():
                    newSet[i[0]]=int(i[1])
                
            self.databases[dictName].add(newSet)
            return
        
        
        
        
        if subquery[0]=="select":
            referencedAttributes = subquery[1:subquery.index("from")]
            if subquery.count("where")>0:
                referencedDatabaseNames = subquery[subquery.index("from")+1:subquery.index("where")]
                referencedDatabases=[]
                for r in referencedDatabaseNames:
                    referencedDatabases.append(self.databases[r])
                conditions=" ".join(subquery[subquery.index("where")+1:])

            else:
                referencedDatabases = subquery[subquery.index("from")+1:]
                conditions="1==1"
            
            print(self.recursiveSelect(referencedDatabases, referencedAttributes, conditions))
            
            return 
            
            
            
            
        if subquery[0]=="update":
            dictName=subquery[1]
            entryItems = subquery[subquery.index("set")+1:subquery.index("where")]
            conditions=" ".join(subquery[subquery.index("where")+1:])
            print(conditions)
            for e in self.databases[dictName].entries:
                    if eval(conditions,{self.databases[dictName].name : e}):
                        for item in entryItems:
                            i =item.split("=")
                            print(i)
                            if i[1].isdigit():
                                e[i[0]]=int(i[1])
                            else:
                               e[i[0]]=i[1]          
            return
            
def main():
    dbms = DBMS()

    dbms.queryHandler("create table student name sid program address")
    dbms.queryHandler("create table course  cid cname credits")
    dbms.queryHandler("create table enrolled sid cid grade")

    dbms.queryHandler("insert into student sid=1234 name=alex program=compsci address=123road")
    dbms.queryHandler("insert into student sid=1235 name=joe program=polisci address=123street")
    dbms.queryHandler("insert into student sid=1236 name=pete program=compsci address=123ave")
    dbms.queryHandler("insert into course cid=c353 cname=databases credits=3")
    dbms.queryHandler("insert into course cid=424 cname=economics credits=2")
    dbms.queryHandler("insert into enrolled cid=c353 sid=1234 grade=90")
    dbms.queryHandler("insert into enrolled cid=c424 sid=1235 grade=20")
    dbms.queryHandler("insert into enrolled cid=c353 sid=1236 grade=30")

    dbms.queryHandler("select student.name student.sid from enrolled student course where enrolled.cid == \"c353\" and enrolled.grade > 80 and enrolled.cid == course.cid and student.sid == enrolled.sid")

if __name__ == "__main__":
    main()